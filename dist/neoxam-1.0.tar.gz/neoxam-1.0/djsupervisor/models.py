"""

djsupervisor.models:  fake models file for djsupervisor
-------------------------------------------------------

This application doesn't actually define any models.  But Django will freak out
if it's missing a "models.py file, so here we are...

"""


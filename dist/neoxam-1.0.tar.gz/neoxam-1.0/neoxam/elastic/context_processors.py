# -*- coding: utf-8 -*-

def kibana(request):
    return {
        'kibana_url': 'http://iadev-tools:5601/',
    }

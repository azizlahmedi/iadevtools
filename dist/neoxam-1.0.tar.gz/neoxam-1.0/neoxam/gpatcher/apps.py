# -*- coding: utf-8 -*-
from django.apps import AppConfig


class GpatcherConfig(AppConfig):
    name = 'gpatcher'

# -*- coding: utf-8 -*-
from django.apps import AppConfig


class InitialCommitConfig(AppConfig):
    name = 'initial'

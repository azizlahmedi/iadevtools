from django.apps import AppConfig


class VersioningConfig(AppConfig):
    name = 'versioning'
